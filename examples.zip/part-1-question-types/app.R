# Load packages
library(surveydown)

db <- sd_db_connect(ignore = TRUE)

ui <- sd_ui()

server <- function(input, output, session) {

  sd_server(db = db)

}

# Launch the app
shiny::shinyApp(ui = ui, server = server)
