# Load packages
library(surveydown)
library(dplyr)
library(ggplot2)

# Must have database connected for this example - run to store db credentials:
# sd_db_config()
db <- sd_db_connect()

# UI setup --------------------------------------------------------------------

ui <- sd_ui()

# Server setup ----------------------------------------------------------------

server <- function(input, output, session) {

    # Refresh data every 5 seconds
    data <- sd_get_data(db, refresh_interval = 5)

    # Render the plot
    output$penguin_plot <- renderPlot({
        data() |> # Note the () here, as this is a reactive expression
            count(penguins) |>
            mutate(penguins = ifelse(penguins == '', 'No response', penguins)) |>
            ggplot() +
            geom_col(aes(x = n, y = reorder(penguins, n)), width = 0.7) +
            theme_minimal() +
            labs(x = "Count", y = "Penguin Type", title = "Penguin Count")
    })

    # Database designation and other settings
    sd_server(
        db = db,
        all_questions_required = TRUE,
        use_cookies = FALSE
    )

}

# Launch the app
shiny::shinyApp(ui = ui, server = server)
